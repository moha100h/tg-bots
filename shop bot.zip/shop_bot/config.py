import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

# آیدی عددی ادمین‌ها (تلگرام آیدی) - با کاما جدا شوند، مثل: 111111,222222
_admin_ids_raw = os.getenv("ADMIN_IDS", "")
ADMIN_IDS = {int(x.strip()) for x in _admin_ids_raw.split(",") if x.strip().isdigit()}

DB_PATH = os.getenv("DB_PATH", "shop.db")

# مقادیر پیش‌فرض اولیه برای شماره کارت (بعدا از داخل بات هم قابل تغییر است)
DEFAULT_CARD_NUMBER = os.getenv("CARD_NUMBER", "0000-0000-0000-0000")
DEFAULT_CARD_HOLDER = os.getenv("CARD_HOLDER", "نام صاحب کارت")

PRODUCTS_PER_PAGE = 6
