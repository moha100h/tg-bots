# بات فروشگاهی تلگرام

بات کامل فروشگاهی با aiogram 3 (پایتون، async) و SQLite. امکانات:

**برای مشتری:**
- مرور دسته‌بندی و زیردسته‌بندی محصولات
- جستجوی محصول
- مشاهده محصول با عکس، توضیحات، قیمت، موجودی
- سبد خرید (افزایش/کاهش تعداد، حذف)
- ثبت سفارش، پرداخت کارت‌به‌کارت، ارسال عکس رسید
- پیگیری وضعیت سفارش‌ها

**برای ادمین (`/admin`):**
- مدیریت کامل دسته‌بندی و زیردسته‌بندی (افزودن/ویرایش/حذف)
- مدیریت محصولات: افزودن با عکس/قیمت/موجودی/توضیحات، ویرایش هر فیلد، فعال/غیرفعال کردن، حذف
- بررسی سفارش‌های در انتظار + مشاهده رسید پرداخت + تایید یا رد (با اطلاع‌رسانی خودکار به مشتری)
- تغییر شماره کارت و نام صاحب کارت از داخل بات
- آمار فروشگاه (تعداد کاربران، محصولات فعال، سفارش‌های تایید شده، درآمد کل)

می‌توانید چند ادمین همزمان داشته باشید.

---

## ۱. ساخت بات و گرفتن توکن

1. در تلگرام به [@BotFather](https://t.me/BotFather) پیام دهید.
2. دستور `/newbot` را بزنید و نام و یوزرنیم بات را وارد کنید.
3. توکنی که می‌دهد را کپی کنید.
4. آیدی عددی خودتان را از [@userinfobot](https://t.me/userinfobot) بگیرید (برای دسترسی ادمین لازم است).

## ۲. آپلود پروژه روی VPS

با هر روشی (FileZilla، scp، git) کل پوشه `shop_bot` را روی سرور کپی کنید. مثال با scp از کامپیوتر خودتان:

```bash
scp -r shop_bot root@IP_SERVER:/opt/shop_bot
```

## ۳. نصب پایتون و پکیج‌ها روی سرور

```bash
ssh root@IP_SERVER
cd /opt/shop_bot
sudo apt update && sudo apt install -y python3 python3-venv python3-pip

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## ۴. تنظیم فایل `.env`

```bash
cp .env.example .env
nano .env
```

مقادیر زیر را با اطلاعات خودتان پر کنید و ذخیره کنید (`Ctrl+O` سپس `Ctrl+X`):

```
BOT_TOKEN=توکن_بات_شما
ADMIN_IDS=آیدی_عددی_شما
CARD_NUMBER=شماره_کارت_شما
CARD_HOLDER=نام_صاحب_کارت
```

اگر چند ادمین دارید: `ADMIN_IDS=111111,222222`

## ۵. تست اجرا

```bash
source venv/bin/activate
python3 main.py
```

اگر پیام خطا نبود، در تلگرام به بات خودتان `/start` بزنید و تست کنید. سپس با `Ctrl+C` متوقف کنید و برای اجرای دائمی به مرحله بعد بروید.

## ۶. اجرای ۲۴ ساعته با systemd (پیشنهادی)

فایل سرویس بسازید:

```bash
sudo nano /etc/systemd/system/shopbot.service
```

این محتوا را وارد کنید (مسیر `/opt/shop_bot` را اگر فرق دارد اصلاح کنید):

```ini
[Unit]
Description=Telegram Shop Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/shop_bot
ExecStart=/opt/shop_bot/venv/bin/python3 /opt/shop_bot/main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

سپس فعال‌سازی:

```bash
sudo systemctl daemon-reload
sudo systemctl enable shopbot
sudo systemctl start shopbot
```

بررسی وضعیت و لاگ:

```bash
sudo systemctl status shopbot
journalctl -u shopbot -f
```

از این به بعد بات ۲۴ ساعته اجرا می‌شود و حتی بعد از ریبوت سرور خودش بالا می‌آید.

## ۷. شروع به کار

1. در تلگرام به بات `/admin` بزنید (فقط آیدی‌های داخل `ADMIN_IDS` این دستور را می‌بینند).
2. اول از «📁 مدیریت دسته‌بندی‌ها» چند دسته (مثلاً «پوشاک»، «لوازم جانبی») و در صورت نیاز زیردسته بسازید.
3. از «🏷 مدیریت محصولات» یک دسته را انتخاب کرده و محصولات را با عکس، قیمت، توضیحات و موجودی اضافه کنید.
4. از «💳 تنظیمات پرداخت» شماره کارت را تنظیم کنید (اگر در `.env` نزده بودید).
5. بات را به مشتری‌ها معرفی کنید؛ سفارش‌های جدید با عکس رسید مستقیماً برای شما ارسال می‌شود و با یک دکمه تایید/رد می‌کنید.

## نکات توسعه بعدی (اختیاری)
- اتصال درگاه پرداخت آنلاین (زرین‌پال و...) به‌جای کارت‌به‌کارت
- پنل وب مدیریتی جدا
- ارسال نوتیفیکیشن وضعیت ارسال مرسوله
- پشتیبان‌گیری دوره‌ای از فایل `shop.db` (`cp shop.db backup/shop_$(date +%F).db`)

## ساختار پروژه
```
shop_bot/
├── main.py              # اجرای بات
├── config.py            # تنظیمات (.env)
├── database.py          # تمام عملیات دیتابیس
├── states.py            # مراحل گفت‌وگو (FSM)
├── keyboards/
│   ├── user_kb.py
│   └── admin_kb.py
├── handlers/
│   ├── user.py          # منطق سمت مشتری
│   └── admin.py         # منطق پنل مدیریت
├── requirements.txt
└── .env.example
```
