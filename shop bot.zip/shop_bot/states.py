from aiogram.fsm.state import State, StatesGroup


class AddCategory(StatesGroup):
    name = State()


class RenameCategory(StatesGroup):
    waiting_name = State()


class AddProduct(StatesGroup):
    category = State()
    name = State()
    description = State()
    price = State()
    stock = State()
    photo = State()


class EditProduct(StatesGroup):
    waiting_value = State()


class Checkout(StatesGroup):
    full_name = State()
    phone = State()
    address = State()
    waiting_receipt = State()


class AdminSettings(StatesGroup):
    card_number = State()
    card_holder = State()


class SearchProduct(StatesGroup):
    keyword = State()


class RejectOrder(StatesGroup):
    reason = State()
