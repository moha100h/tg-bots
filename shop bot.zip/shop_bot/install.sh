#!/usr/bin/env bash
# ============================================================
#  نصب خودکار بات فروشگاهی تلگرام
#  فقط توکن بات و آیدی عددی ادمین را می‌پرسد و بقیه کار را
#  خودش انجام می‌دهد: پوشه ایزوله، venv، نصب پکیج‌ها،
#  ساخت .env، ساخت و فعال‌سازی سرویس systemd مخصوص همین بات.
#
#  این اسکریپت برای هر بات یک پوشه و یک سرویس systemd
#  جداگانه و یکتا (بر اساس شناسه عددی بات) می‌سازد، بنابراین
#  با سایر بات‌های نصب‌شده روی همین VPS تداخلی پیش نمی‌آید.
# ============================================================

set -euo pipefail

# ---------- رنگ‌ها برای خوانایی بهتر ----------
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[+]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
fail()  { echo -e "${RED}[x]${NC} $1"; exit 1; }

# ---------- اجرا با sudo در صورت نیاز ----------
if [[ "$EUID" -ne 0 ]]; then
    SUDO="sudo"
else
    SUDO=""
fi

# ---------- مسیر سورس (همین پوشه که install.sh داخلش است) ----------
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================================"
echo "          نصب خودکار بات فروشگاهی تلگرام"
echo "============================================================"
echo

# ---------- گرفتن توکن بات ----------
BOT_TOKEN="${1:-}"
if [[ -z "$BOT_TOKEN" ]]; then
    read -rp "توکن بات تلگرام (از @BotFather) را وارد کنید: " BOT_TOKEN
fi
if ! [[ "$BOT_TOKEN" =~ ^[0-9]+:[A-Za-z0-9_-]{20,}$ ]]; then
    fail "فرمت توکن نامعتبر است. توکن باید شبیه 123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx باشد."
fi

# ---------- گرفتن آیدی عددی ادمین ----------
ADMIN_IDS="${2:-}"
if [[ -z "$ADMIN_IDS" ]]; then
    read -rp "آیدی عددی ادمین (در صورت چند ادمین با کاما جدا کنید، مثل 111,222): " ADMIN_IDS
fi
if ! [[ "$ADMIN_IDS" =~ ^[0-9]+(,[0-9]+)*$ ]]; then
    fail "فرمت آیدی ادمین نامعتبر است. فقط عدد و در صورت چند ادمین با کاما جدا کنید."
fi

# ---------- ساخت نام و مسیر یکتا بر اساس شناسه بات ----------
BOT_ID="${BOT_TOKEN%%:*}"
BASE_DIR="/opt/tg-bots"
INSTALL_DIR="${BASE_DIR}/shop-bot-${BOT_ID}"
SERVICE_NAME="shop-bot-${BOT_ID}"

if [[ -d "$INSTALL_DIR" ]]; then
    warn "پوشه‌ای با این بات قبلاً وجود دارد: $INSTALL_DIR"
    read -rp "آیا می‌خواهید آن را بازنویسی/به‌روزرسانی کنید؟ (y/n): " OVERWRITE
    if [[ "$OVERWRITE" != "y" && "$OVERWRITE" != "Y" ]]; then
        fail "نصب لغو شد."
    fi
    $SUDO systemctl stop "$SERVICE_NAME" 2>/dev/null || true
fi

info "مسیر نصب ایزوله: $INSTALL_DIR"
info "نام سرویس: $SERVICE_NAME"

# ---------- نصب پیش‌نیازهای سیستمی ----------
if ! command -v python3 >/dev/null 2>&1 || ! python3 -m venv --help >/dev/null 2>&1; then
    info "در حال نصب پایتون و ابزارهای مورد نیاز..."
    $SUDO apt-get update -y -qq
    $SUDO apt-get install -y -qq python3 python3-venv python3-pip rsync
else
    info "پایتون از قبل نصب است، رد شدن از این مرحله."
fi

# ---------- کپی سورس به پوشه ایزوله ----------
$SUDO mkdir -p "$BASE_DIR"
$SUDO mkdir -p "$INSTALL_DIR"
$SUDO chown "$(id -u)":"$(id -g)" "$INSTALL_DIR"

info "در حال کپی فایل‌های پروژه به پوشه ایزوله..."
rsync -a --exclude 'venv' --exclude '__pycache__' --exclude '.git' \
    --exclude 'shop.db' --exclude '.env' --exclude 'install.sh' \
    "$SOURCE_DIR"/ "$INSTALL_DIR"/

cd "$INSTALL_DIR"

# ---------- ساخت محیط مجازی و نصب پکیج‌ها ----------
info "ساخت محیط مجازی پایتون و نصب پکیج‌ها..."
python3 -m venv venv
./venv/bin/pip install --upgrade pip -q
./venv/bin/pip install -r requirements.txt -q

# ---------- ساخت فایل .env ----------
info "ساخت فایل تنظیمات .env ..."
cat > "$INSTALL_DIR/.env" <<EOF
BOT_TOKEN=${BOT_TOKEN}
ADMIN_IDS=${ADMIN_IDS}
DB_PATH=shop.db
CARD_NUMBER=0000-0000-0000-0000
CARD_HOLDER=نام صاحب کارت را از داخل پنل ادمین تغییر دهید
EOF
chmod 600 "$INSTALL_DIR/.env"

# ---------- ساخت سرویس systemd مخصوص همین بات ----------
info "ساخت سرویس systemd با نام $SERVICE_NAME ..."
RUN_USER="$(id -un)"
$SUDO tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=Telegram Shop Bot (${BOT_ID})
After=network.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/venv/bin/python3 ${INSTALL_DIR}/main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

$SUDO systemctl daemon-reload
$SUDO systemctl enable "$SERVICE_NAME" -q
$SUDO systemctl restart "$SERVICE_NAME"

sleep 2

echo
echo "============================================================"
if $SUDO systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "${GREEN}✅ نصب با موفقیت کامل شد و بات در حال اجراست.${NC}"
else
    echo -e "${RED}❌ سرویس بالا نیامد. خروجی لاگ زیر را بررسی کنید:${NC}"
    $SUDO journalctl -u "$SERVICE_NAME" --no-pager -n 30
    exit 1
fi
echo "============================================================"
echo "📁 مسیر نصب:      $INSTALL_DIR"
echo "🔧 نام سرویس:      $SERVICE_NAME"
echo "📜 دیدن لاگ زنده:  sudo journalctl -u $SERVICE_NAME -f"
echo "🔁 ری‌استارت:      sudo systemctl restart $SERVICE_NAME"
echo "⏹  توقف:          sudo systemctl stop $SERVICE_NAME"
echo "🗑  حذف کامل:      sudo systemctl disable --now $SERVICE_NAME && sudo rm -rf $INSTALL_DIR /etc/systemd/system/${SERVICE_NAME}.service"
echo "============================================================"
echo "حالا در تلگرام به بات خودتان /start و سپس /admin بزنید."
