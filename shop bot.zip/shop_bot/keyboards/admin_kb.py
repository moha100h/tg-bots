from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_main_kb() -> ReplyKeyboardMarkup:
    kb = [
        [KeyboardButton(text="📁 مدیریت دسته‌بندی‌ها"), KeyboardButton(text="🏷 مدیریت محصولات")],
        [KeyboardButton(text="📦 سفارش‌های در انتظار"), KeyboardButton(text="📊 آمار فروشگاه")],
        [KeyboardButton(text="💳 تنظیمات پرداخت"), KeyboardButton(text="🏠 خروج از پنل ادمین")],
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)


def admin_categories_kb(categories, parent_id=None) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for cat_id, name, _ in categories:
        b.row(
            InlineKeyboardButton(text=f"📁 {name}", callback_data=f"acat_open:{cat_id}"),
            InlineKeyboardButton(text="✏️", callback_data=f"acat_ren:{cat_id}"),
            InlineKeyboardButton(text="🗑", callback_data=f"acat_del:{cat_id}"),
        )
    b.row(InlineKeyboardButton(text="➕ افزودن دسته‌بندی جدید", callback_data=f"acat_add:{parent_id or 0}"))
    if parent_id:
        b.row(InlineKeyboardButton(text="⬅️ بازگشت", callback_data=f"acat_back:{parent_id}"))
    return b.as_markup()


def pick_category_kb(categories, prefix="pickcat") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for cat_id, name, _ in categories:
        b.row(InlineKeyboardButton(text=f"📁 {name}", callback_data=f"{prefix}:{cat_id}"))
    return b.as_markup()


def admin_products_list_kb(products) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for p_id, name, price, stock, is_active in products:
        status = "✅" if is_active else "⛔️"
        b.row(InlineKeyboardButton(text=f"{status} {name} ({stock} عدد)", callback_data=f"aprod_open:{p_id}"))
    return b.as_markup()


def admin_product_detail_kb(product_id, is_active) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="✏️ نام", callback_data=f"aprod_edit:name:{product_id}"),
        InlineKeyboardButton(text="✏️ توضیحات", callback_data=f"aprod_edit:description:{product_id}"),
    )
    b.row(
        InlineKeyboardButton(text="✏️ قیمت", callback_data=f"aprod_edit:price:{product_id}"),
        InlineKeyboardButton(text="✏️ موجودی", callback_data=f"aprod_edit:stock:{product_id}"),
    )
    b.row(InlineKeyboardButton(text="✏️ تصویر", callback_data=f"aprod_edit:photo:{product_id}"))
    toggle_text = "⛔️ غیرفعال کردن" if is_active else "✅ فعال کردن"
    b.row(InlineKeyboardButton(text=toggle_text, callback_data=f"aprod_toggle:{product_id}"))
    b.row(InlineKeyboardButton(text="🗑 حذف محصول", callback_data=f"aprod_del:{product_id}"))
    return b.as_markup()


def admin_order_action_kb(order_id) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="✅ تایید سفارش", callback_data=f"order_confirm:{order_id}"),
        InlineKeyboardButton(text="❌ رد سفارش", callback_data=f"order_reject:{order_id}"),
    )
    return b.as_markup()


def admin_cancel_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="❌ انصراف", callback_data="admin_cancel_flow"))
    return b.as_markup()
