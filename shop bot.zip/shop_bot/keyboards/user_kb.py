from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import PRODUCTS_PER_PAGE


def main_menu_kb() -> ReplyKeyboardMarkup:
    kb = [
        [KeyboardButton(text="🛍 دسته‌بندی‌ها"), KeyboardButton(text="🔎 جستجوی محصول")],
        [KeyboardButton(text="🛒 سبد خرید"), KeyboardButton(text="📦 سفارش‌های من")],
        [KeyboardButton(text="📞 پشتیبانی")],
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)


def categories_kb(categories, parent_id=None, show_back=False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for cat_id, name, _ in categories:
        b.row(InlineKeyboardButton(text=f"📁 {name}", callback_data=f"cat:{cat_id}"))
    if show_back:
        back_to = parent_id if parent_id else "root"
        b.row(InlineKeyboardButton(text="⬅️ بازگشت", callback_data=f"catback:{back_to}"))
    return b.as_markup()


def category_view_kb(category_id, products, parent_id, page=0, total_pages=1) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for p_id, name, price, stock in products:
        label = f"{name} - {price:,} تومان" + (" (ناموجود)" if stock <= 0 else "")
        b.row(InlineKeyboardButton(text=label, callback_data=f"prod:{p_id}"))
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️ قبلی", callback_data=f"catpage:{category_id}:{page-1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton(text="بعدی ▶️", callback_data=f"catpage:{category_id}:{page+1}"))
    if nav:
        b.row(*nav)
    back_to = parent_id if parent_id else "root"
    b.row(InlineKeyboardButton(text="⬅️ بازگشت", callback_data=f"catback:{back_to}"))
    return b.as_markup()


def product_view_kb(product_id, category_id, in_stock=True) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if in_stock:
        b.row(InlineKeyboardButton(text="➕ افزودن به سبد خرید", callback_data=f"addcart:{product_id}"))
    b.row(InlineKeyboardButton(text="⬅️ بازگشت به دسته", callback_data=f"catback_view:{category_id}"))
    return b.as_markup()


def cart_kb(items) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for p_id, name, price, qty, stock in items:
        b.row(
            InlineKeyboardButton(text="➖", callback_data=f"cartdec:{p_id}"),
            InlineKeyboardButton(text=f"{name} × {qty}", callback_data="noop"),
            InlineKeyboardButton(text="➕", callback_data=f"cartinc:{p_id}"),
            InlineKeyboardButton(text="🗑", callback_data=f"cartdel:{p_id}"),
        )
    if items:
        b.row(InlineKeyboardButton(text="✅ ثبت سفارش و پرداخت", callback_data="checkout"))
        b.row(InlineKeyboardButton(text="🗑 خالی کردن سبد", callback_data="cartclear"))
    return b.as_markup()


def confirm_checkout_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="✅ تایید و ادامه", callback_data="checkout_confirm"))
    b.row(InlineKeyboardButton(text="❌ انصراف", callback_data="checkout_cancel"))
    return b.as_markup()


def cancel_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="❌ انصراف", callback_data="cancel_flow"))
    return b.as_markup()
