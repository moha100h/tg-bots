import aiosqlite
from datetime import datetime
from config import DB_PATH, DEFAULT_CARD_NUMBER, DEFAULT_CARD_HOLDER

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    full_name TEXT,
    phone TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    price INTEGER NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    photo_file_id TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cart_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_telegram_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL DEFAULT 1,
    UNIQUE(user_telegram_id, product_id)
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_telegram_id INTEGER NOT NULL,
    full_name TEXT,
    phone TEXT,
    address TEXT,
    total_price INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending_receipt',
    receipt_photo_file_id TEXT,
    admin_note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER,
    product_name TEXT NOT NULL,
    price INTEGER NOT NULL,
    quantity INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES ('card_number', ?)",
            (DEFAULT_CARD_NUMBER,),
        )
        await db.execute(
            "INSERT OR IGNORE INTO settings(key, value) VALUES ('card_holder', ?)",
            (DEFAULT_CARD_HOLDER,),
        )
        await db.commit()


# ---------------- Users ----------------
async def upsert_user(telegram_id: int, username: str, full_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO users (telegram_id, username, full_name)
               VALUES (?, ?, ?)
               ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, full_name=excluded.full_name""",
            (telegram_id, username, full_name),
        )
        await db.commit()


# ---------------- Settings ----------------
async def get_setting(key: str, default: str = "") -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
        return row[0] if row else default


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        await db.commit()


# ---------------- Categories ----------------
async def add_category(name: str, parent_id: int | None = None) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO categories (name, parent_id) VALUES (?, ?)", (name, parent_id)
        )
        await db.commit()
        return cur.lastrowid


async def get_categories(parent_id: int | None = None):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, name, parent_id FROM categories WHERE parent_id IS ? ORDER BY name",
            (parent_id,),
        )
        return await cur.fetchall()


async def get_all_categories():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT id, name, parent_id FROM categories ORDER BY name")
        return await cur.fetchall()


async def get_category(category_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, name, parent_id FROM categories WHERE id=?", (category_id,)
        )
        return await cur.fetchone()


async def delete_category(category_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM categories WHERE id=?", (category_id,))
        await db.commit()


async def rename_category(category_id: int, new_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE categories SET name=? WHERE id=?", (new_name, category_id))
        await db.commit()


# ---------------- Products ----------------
async def add_product(category_id, name, description, price, stock, photo_file_id) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """INSERT INTO products (category_id, name, description, price, stock, photo_file_id)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (category_id, name, description, price, stock, photo_file_id),
        )
        await db.commit()
        return cur.lastrowid


async def get_products_by_category(category_id: int, only_active=True):
    async with aiosqlite.connect(DB_PATH) as db:
        q = "SELECT id, name, description, price, stock, photo_file_id, is_active FROM products WHERE category_id=?"
        if only_active:
            q += " AND is_active=1"
        q += " ORDER BY id DESC"
        cur = await db.execute(q, (category_id,))
        return await cur.fetchall()


async def get_product(product_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT id, category_id, name, description, price, stock, photo_file_id, is_active
               FROM products WHERE id=?""",
            (product_id,),
        )
        return await cur.fetchone()


async def update_product_field(product_id: int, field: str, value):
    assert field in {"name", "description", "price", "stock", "photo_file_id", "is_active", "category_id"}
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE products SET {field}=? WHERE id=?", (value, product_id))
        await db.commit()


async def delete_product(product_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM products WHERE id=?", (product_id,))
        await db.commit()


async def decrease_stock(product_id: int, qty: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE products SET stock = MAX(stock - ?, 0) WHERE id=?", (qty, product_id)
        )
        await db.commit()


async def search_products(keyword: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT id, name, price, stock FROM products
               WHERE is_active=1 AND name LIKE ? ORDER BY id DESC LIMIT 20""",
            (f"%{keyword}%",),
        )
        return await cur.fetchall()


# ---------------- Cart ----------------
async def add_to_cart(user_telegram_id: int, product_id: int, qty: int = 1):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO cart_items (user_telegram_id, product_id, quantity)
               VALUES (?, ?, ?)
               ON CONFLICT(user_telegram_id, product_id) DO UPDATE SET quantity = quantity + ?""",
            (user_telegram_id, product_id, qty, qty),
        )
        await db.commit()


async def set_cart_qty(user_telegram_id: int, product_id: int, qty: int):
    async with aiosqlite.connect(DB_PATH) as db:
        if qty <= 0:
            await db.execute(
                "DELETE FROM cart_items WHERE user_telegram_id=? AND product_id=?",
                (user_telegram_id, product_id),
            )
        else:
            await db.execute(
                "UPDATE cart_items SET quantity=? WHERE user_telegram_id=? AND product_id=?",
                (qty, user_telegram_id, product_id),
            )
        await db.commit()


async def remove_from_cart(user_telegram_id: int, product_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM cart_items WHERE user_telegram_id=? AND product_id=?",
            (user_telegram_id, product_id),
        )
        await db.commit()


async def get_cart(user_telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT p.id, p.name, p.price, c.quantity, p.stock
               FROM cart_items c JOIN products p ON p.id = c.product_id
               WHERE c.user_telegram_id=?""",
            (user_telegram_id,),
        )
        return await cur.fetchall()


async def clear_cart(user_telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM cart_items WHERE user_telegram_id=?", (user_telegram_id,))
        await db.commit()


# ---------------- Orders ----------------
async def create_order(user_telegram_id, full_name, phone, address, total_price, items) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """INSERT INTO orders (user_telegram_id, full_name, phone, address, total_price, status)
               VALUES (?, ?, ?, ?, ?, 'pending_receipt')""",
            (user_telegram_id, full_name, phone, address, total_price),
        )
        order_id = cur.lastrowid
        for it in items:
            await db.execute(
                """INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
                   VALUES (?, ?, ?, ?, ?)""",
                (order_id, it["id"], it["name"], it["price"], it["quantity"]),
            )
        await db.commit()
        return order_id


async def attach_receipt(order_id: int, file_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET receipt_photo_file_id=?, status='pending_review' WHERE id=?",
            (file_id, order_id),
        )
        await db.commit()


async def set_order_status(order_id: int, status: str, admin_note: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET status=?, admin_note=COALESCE(?, admin_note) WHERE id=?",
            (status, admin_note, order_id),
        )
        await db.commit()


async def get_order(order_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT id, user_telegram_id, full_name, phone, address, total_price, status,
                      receipt_photo_file_id, admin_note, created_at
               FROM orders WHERE id=?""",
            (order_id,),
        )
        return await cur.fetchone()


async def get_order_items(order_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT product_id, product_name, price, quantity FROM order_items WHERE order_id=?",
            (order_id,),
        )
        return await cur.fetchall()


async def get_user_orders(user_telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT id, total_price, status, created_at FROM orders
               WHERE user_telegram_id=? ORDER BY id DESC""",
            (user_telegram_id,),
        )
        return await cur.fetchall()


async def get_orders_by_status(status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT id, user_telegram_id, full_name, total_price, created_at
               FROM orders WHERE status=? ORDER BY id DESC""",
            (status,),
        )
        return await cur.fetchall()


# ---------------- Stats ----------------
async def get_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM users")
        users_count = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*) FROM products WHERE is_active=1")
        products_count = (await cur.fetchone())[0]
        cur = await db.execute("SELECT COUNT(*), COALESCE(SUM(total_price),0) FROM orders WHERE status='confirmed'")
        row = await cur.fetchone()
        confirmed_orders, revenue = row[0], row[1]
        cur = await db.execute("SELECT COUNT(*) FROM orders WHERE status='pending_review'")
        pending_review = (await cur.fetchone())[0]
        return {
            "users": users_count,
            "products": products_count,
            "confirmed_orders": confirmed_orders,
            "revenue": revenue,
            "pending_review": pending_review,
        }
