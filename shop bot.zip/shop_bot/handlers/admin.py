from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

import database as db
from keyboards.admin_kb import (
    admin_cancel_kb,
    admin_main_kb, admin_categories_kb, pick_category_kb,
    admin_products_list_kb, admin_product_detail_kb, admin_order_action_kb,
)
from keyboards.user_kb import main_menu_kb
from states import AddCategory, RenameCategory, AddProduct, EditProduct, AdminSettings, RejectOrder
from config import ADMIN_IDS

router = Router()
router.message.filter(F.from_user.id.in_(ADMIN_IDS))
router.callback_query.filter(F.from_user.id.in_(ADMIN_IDS))


# ---------------- ورود به پنل ----------------
@router.message(Command("admin"))
async def admin_panel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("🛠 به پنل مدیریت خوش آمدید.", reply_markup=admin_main_kb())


@router.message(F.text == "🏠 خروج از پنل ادمین")
async def admin_exit(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("از پنل ادمین خارج شدید.", reply_markup=main_menu_kb())


# ---------------- مدیریت دسته‌بندی‌ها ----------------
@router.message(F.text == "📁 مدیریت دسته‌بندی‌ها")
async def manage_categories(message: Message):
    cats = await db.get_categories(parent_id=None)
    await message.answer("📁 دسته‌بندی‌های اصلی:", reply_markup=admin_categories_kb(cats))


@router.callback_query(F.data.startswith("acat_open:"))
async def acat_open(call: CallbackQuery):
    cat_id = int(call.data.split(":")[1])
    cat = await db.get_category(cat_id)
    sub = await db.get_categories(parent_id=cat_id)
    await call.message.edit_text(f"📁 زیردسته‌های «{cat[1]}»:", reply_markup=admin_categories_kb(sub, parent_id=cat_id))
    await call.answer()


@router.callback_query(F.data.startswith("acat_back:"))
async def acat_back(call: CallbackQuery):
    cat_id = int(call.data.split(":")[1])
    cat = await db.get_category(cat_id)
    parent_id = cat[2] if cat else None
    if parent_id:
        parent = await db.get_category(parent_id)
        sub = await db.get_categories(parent_id=parent_id)
        await call.message.edit_text(f"📁 زیردسته‌های «{parent[1]}»:", reply_markup=admin_categories_kb(sub, parent_id=parent_id))
    else:
        cats = await db.get_categories(parent_id=None)
        await call.message.edit_text("📁 دسته‌بندی‌های اصلی:", reply_markup=admin_categories_kb(cats))
    await call.answer()


@router.callback_query(F.data.startswith("acat_add:"))
async def acat_add(call: CallbackQuery, state: FSMContext):
    parent_id = int(call.data.split(":")[1]) or None
    await state.set_state(AddCategory.name)
    await state.update_data(parent_id=parent_id)
    await call.message.answer("نام دسته‌بندی جدید را وارد کنید:", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(AddCategory.name)
async def add_category_name(message: Message, state: FSMContext):
    data = await state.get_data()
    await db.add_category(message.text.strip(), data.get("parent_id"))
    await state.clear()
    cats = await db.get_categories(parent_id=data.get("parent_id"))
    await message.answer("✅ دسته‌بندی اضافه شد.", reply_markup=admin_main_kb())
    await message.answer("لیست به‌روزشده:", reply_markup=admin_categories_kb(cats, parent_id=data.get("parent_id")))


@router.callback_query(F.data.startswith("acat_ren:"))
async def acat_ren(call: CallbackQuery, state: FSMContext):
    cat_id = int(call.data.split(":")[1])
    await state.set_state(RenameCategory.waiting_name)
    await state.update_data(cat_id=cat_id)
    await call.message.answer("نام جدید دسته‌بندی را وارد کنید:", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(RenameCategory.waiting_name)
async def rename_category_msg(message: Message, state: FSMContext):
    data = await state.get_data()
    await db.rename_category(data["cat_id"], message.text.strip())
    await state.clear()
    await message.answer("✅ نام دسته‌بندی بروزرسانی شد.", reply_markup=admin_main_kb())


@router.callback_query(F.data.startswith("acat_del:"))
async def acat_del(call: CallbackQuery):
    cat_id = int(call.data.split(":")[1])
    await db.delete_category(cat_id)
    cats = await db.get_categories(parent_id=None)
    await call.message.edit_text("🗑 دسته‌بندی (و زیردسته‌ها و محصولات آن) حذف شد.\n\n📁 دسته‌بندی‌های اصلی:", reply_markup=admin_categories_kb(cats))
    await call.answer()


@router.callback_query(F.data == "admin_cancel_flow")
async def admin_cancel_flow(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("لغو شد.", reply_markup=admin_main_kb())
    await call.answer()


# ---------------- مدیریت محصولات ----------------
@router.message(F.text == "🏷 مدیریت محصولات")
async def manage_products(message: Message):
    cats = await db.get_all_categories()
    if not cats:
        await message.answer("ابتدا باید حداقل یک دسته‌بندی بسازید.")
        return
    await message.answer("یک دسته‌بندی را انتخاب کنید تا محصولات آن را مدیریت کنید:", reply_markup=pick_category_kb(cats, prefix="amgmt_cat"))


@router.callback_query(F.data.startswith("amgmt_cat:"))
async def amgmt_cat(call: CallbackQuery):
    cat_id = int(call.data.split(":")[1])
    cat = await db.get_category(cat_id)
    products = await db.get_products_by_category(cat_id, only_active=False)
    products_view = [(p[0], p[1], p[3], p[4], p[6]) for p in products]
    kb = admin_products_list_kb(products_view)
    kb.inline_keyboard.append([
        __import__("aiogram").types.InlineKeyboardButton(text="➕ افزودن محصول به این دسته", callback_data=f"aprod_add:{cat_id}")
    ])
    await call.message.edit_text(f"🏷 محصولات دسته «{cat[1]}»:", reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith("aprod_add:"))
async def aprod_add(call: CallbackQuery, state: FSMContext):
    cat_id = int(call.data.split(":")[1])
    await state.set_state(AddProduct.name)
    await state.update_data(category_id=cat_id)
    await call.message.answer("نام محصول را وارد کنید:", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(AddProduct.name)
async def add_product_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(AddProduct.description)
    await message.answer("توضیحات محصول را وارد کنید (یا - بفرستید برای رد کردن):", reply_markup=admin_cancel_kb())


@router.message(AddProduct.description)
async def add_product_desc(message: Message, state: FSMContext):
    desc = "" if message.text.strip() == "-" else message.text.strip()
    await state.update_data(description=desc)
    await state.set_state(AddProduct.price)
    await message.answer("قیمت محصول را به تومان وارد کنید (فقط عدد):", reply_markup=admin_cancel_kb())


@router.message(AddProduct.price)
async def add_product_price(message: Message, state: FSMContext):
    if not message.text.strip().isdigit():
        await message.answer("لطفاً فقط عدد وارد کنید.")
        return
    await state.update_data(price=int(message.text.strip()))
    await state.set_state(AddProduct.stock)
    await message.answer("تعداد موجودی را وارد کنید (فقط عدد):", reply_markup=admin_cancel_kb())


@router.message(AddProduct.stock)
async def add_product_stock(message: Message, state: FSMContext):
    if not message.text.strip().isdigit():
        await message.answer("لطفاً فقط عدد وارد کنید.")
        return
    await state.update_data(stock=int(message.text.strip()))
    await state.set_state(AddProduct.photo)
    await message.answer("یک تصویر برای محصول ارسال کنید (یا - بفرستید برای رد کردن):", reply_markup=admin_cancel_kb())


@router.message(AddProduct.photo, F.photo)
async def add_product_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    photo_file_id = message.photo[-1].file_id
    await db.add_product(data["category_id"], data["name"], data["description"], data["price"], data["stock"], photo_file_id)
    await state.clear()
    await message.answer("✅ محصول با موفقیت اضافه شد.", reply_markup=admin_main_kb())


@router.message(AddProduct.photo, F.text == "-")
async def add_product_no_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    await db.add_product(data["category_id"], data["name"], data["description"], data["price"], data["stock"], None)
    await state.clear()
    await message.answer("✅ محصول با موفقیت اضافه شد (بدون تصویر).", reply_markup=admin_main_kb())


@router.message(AddProduct.photo)
async def add_product_photo_wrong(message: Message):
    await message.answer("لطفاً یک عکس ارسال کنید یا برای رد کردن - بفرستید.")


# ---------------- جزئیات و ویرایش محصول ----------------
@router.callback_query(F.data.startswith("aprod_open:"))
async def aprod_open(call: CallbackQuery):
    p_id = int(call.data.split(":")[1])
    p = await db.get_product(p_id)
    if not p:
        await call.answer("یافت نشد.", show_alert=True)
        return
    _, category_id, name, description, price, stock, photo_file_id, is_active = p
    caption = f"🏷 {name}\n{description or ''}\n\n💰 {price:,} تومان\n📦 موجودی: {stock}\nوضعیت: {'فعال ✅' if is_active else 'غیرفعال ⛔️'}"
    kb = admin_product_detail_kb(p_id, is_active)
    await call.message.answer(caption, reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith("aprod_edit:"))
async def aprod_edit(call: CallbackQuery, state: FSMContext):
    _, field, p_id = call.data.split(":")
    await state.set_state(EditProduct.waiting_value)
    await state.update_data(field=field, product_id=int(p_id))
    prompts = {
        "name": "نام جدید را وارد کنید:",
        "description": "توضیحات جدید را وارد کنید:",
        "price": "قیمت جدید را به تومان وارد کنید (فقط عدد):",
        "stock": "موجودی جدید را وارد کنید (فقط عدد):",
        "photo": "تصویر جدید را ارسال کنید:",
    }
    await call.message.answer(prompts[field], reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(EditProduct.waiting_value, F.photo)
async def edit_product_photo(message: Message, state: FSMContext):
    data = await state.get_data()
    if data["field"] != "photo":
        await message.answer("لطفاً مقدار متنی ارسال کنید، نه عکس.")
        return
    await db.update_product_field(data["product_id"], "photo_file_id", message.photo[-1].file_id)
    await state.clear()
    await message.answer("✅ تصویر بروزرسانی شد.", reply_markup=admin_main_kb())


@router.message(EditProduct.waiting_value)
async def edit_product_value(message: Message, state: FSMContext):
    data = await state.get_data()
    field = data["field"]
    value = message.text.strip()
    if field in ("price", "stock"):
        if not value.isdigit():
            await message.answer("لطفاً فقط عدد وارد کنید.")
            return
        value = int(value)
    if field == "photo":
        await message.answer("لطفاً یک عکس ارسال کنید.")
        return
    await db.update_product_field(data["product_id"], field, value)
    await state.clear()
    await message.answer("✅ بروزرسانی شد.", reply_markup=admin_main_kb())


@router.callback_query(F.data.startswith("aprod_toggle:"))
async def aprod_toggle(call: CallbackQuery):
    p_id = int(call.data.split(":")[1])
    p = await db.get_product(p_id)
    new_state = 0 if p[7] else 1
    await db.update_product_field(p_id, "is_active", new_state)
    await call.message.edit_reply_markup(reply_markup=admin_product_detail_kb(p_id, new_state))
    await call.answer("وضعیت تغییر کرد.")


@router.callback_query(F.data.startswith("aprod_del:"))
async def aprod_del(call: CallbackQuery):
    p_id = int(call.data.split(":")[1])
    await db.delete_product(p_id)
    await call.message.edit_text("🗑 محصول حذف شد.")
    await call.answer()


# ---------------- سفارش‌ها ----------------
STATUS_FA = {
    "pending_receipt": "⏳ در انتظار ارسال رسید",
    "pending_review": "🔍 در انتظار بررسی",
    "confirmed": "✅ تایید شده",
    "rejected": "❌ رد شده",
}


@router.message(F.text == "📦 سفارش‌های در انتظار")
async def pending_orders(message: Message):
    orders = await db.get_orders_by_status("pending_review")
    if not orders:
        await message.answer("سفارش در انتظار بررسی وجود ندارد.")
        return
    for order_id, user_id, full_name, total, created_at in orders:
        order = await db.get_order(order_id)
        text = f"سفارش #{order_id}\n👤 {full_name}\n💰 {total:,} تومان\n🕒 {created_at}"
        if order[7]:
            await message.answer_photo(order[7], caption=text, reply_markup=admin_order_action_kb(order_id))
        else:
            await message.answer(text, reply_markup=admin_order_action_kb(order_id))


@router.callback_query(F.data.startswith("order_confirm:"))
async def order_confirm(call: CallbackQuery, bot: Bot):
    order_id = int(call.data.split(":")[1])
    order = await db.get_order(order_id)
    if not order or order[6] == "confirmed":
        await call.answer("این سفارش قبلاً پردازش شده.", show_alert=True)
        return
    items = await db.get_order_items(order_id)
    for product_id, name, price, qty in items:
        if product_id:
            await db.decrease_stock(product_id, qty)
    await db.set_order_status(order_id, "confirmed")
    await call.message.answer(f"✅ سفارش #{order_id} تایید شد.")
    try:
        await bot.send_message(order[1], f"✅ سفارش شما با شماره #{order_id} تایید شد. به زودی ارسال خواهد شد.")
    except Exception:
        pass
    await call.answer()


@router.callback_query(F.data.startswith("order_reject:"))
async def order_reject(call: CallbackQuery, state: FSMContext):
    order_id = int(call.data.split(":")[1])
    await state.set_state(RejectOrder.reason)
    await state.update_data(order_id=order_id)
    await call.message.answer("دلیل رد سفارش را بنویسید (برای کاربر ارسال می‌شود):", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(RejectOrder.reason)
async def reject_reason(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    order_id = data["order_id"]
    reason = message.text.strip()
    order = await db.get_order(order_id)
    await db.set_order_status(order_id, "rejected", reason)
    await state.clear()
    await message.answer(f"❌ سفارش #{order_id} رد شد.", reply_markup=admin_main_kb())
    try:
        await bot.send_message(order[1], f"❌ سفارش شما با شماره #{order_id} رد شد.\nدلیل: {reason}")
    except Exception:
        pass


# ---------------- تنظیمات پرداخت ----------------
@router.message(F.text == "💳 تنظیمات پرداخت")
async def payment_settings(message: Message):
    card_number = await db.get_setting("card_number")
    card_holder = await db.get_setting("card_holder")
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="✏️ تغییر شماره کارت", callback_data="set_card_number"))
    b.row(InlineKeyboardButton(text="✏️ تغییر نام صاحب کارت", callback_data="set_card_holder"))
    await message.answer(
        f"💳 شماره کارت فعلی:\n<code>{card_number}</code>\nبه نام: {card_holder}",
        reply_markup=b.as_markup(), parse_mode="HTML",
    )


@router.callback_query(F.data == "set_card_number")
async def set_card_number(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminSettings.card_number)
    await call.message.answer("شماره کارت جدید را وارد کنید:", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(AdminSettings.card_number)
async def save_card_number(message: Message, state: FSMContext):
    await db.set_setting("card_number", message.text.strip())
    await state.clear()
    await message.answer("✅ شماره کارت بروزرسانی شد.", reply_markup=admin_main_kb())


@router.callback_query(F.data == "set_card_holder")
async def set_card_holder(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminSettings.card_holder)
    await call.message.answer("نام جدید صاحب کارت را وارد کنید:", reply_markup=admin_cancel_kb())
    await call.answer()


@router.message(AdminSettings.card_holder)
async def save_card_holder(message: Message, state: FSMContext):
    await db.set_setting("card_holder", message.text.strip())
    await state.clear()
    await message.answer("✅ نام صاحب کارت بروزرسانی شد.", reply_markup=admin_main_kb())


# ---------------- آمار ----------------
@router.message(F.text == "📊 آمار فروشگاه")
async def stats(message: Message):
    s = await db.get_stats()
    text = (
        f"📊 آمار فروشگاه:\n\n"
        f"👥 تعداد کاربران: {s['users']}\n"
        f"🏷 محصولات فعال: {s['products']}\n"
        f"✅ سفارش‌های تایید شده: {s['confirmed_orders']}\n"
        f"💰 درآمد کل: {s['revenue']:,} تومان\n"
        f"🔍 سفارش‌های در انتظار بررسی: {s['pending_review']}"
    )
    await message.answer(text)
