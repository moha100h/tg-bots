from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery, InputMediaPhoto
from aiogram.fsm.context import FSMContext

import database as db
from keyboards.user_kb import (
    main_menu_kb, categories_kb, category_view_kb, product_view_kb,
    cart_kb, confirm_checkout_kb, cancel_kb,
)
from keyboards.admin_kb import admin_order_action_kb
from states import Checkout, SearchProduct
from config import ADMIN_IDS, PRODUCTS_PER_PAGE

router = Router()


# ---------------- شروع ----------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await db.upsert_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    await message.answer(
        "👋 سلام! به فروشگاه ما خوش آمدید.\n\nاز منوی پایین می‌توانید محصولات را مشاهده و سفارش ثبت کنید.",
        reply_markup=main_menu_kb(),
    )


@router.message(F.text == "📞 پشتیبانی")
async def support(message: Message):
    await message.answer("برای ارتباط با پشتیبانی پیام خود را همینجا بنویسید، در سریع‌ترین زمان پاسخ داده می‌شود.")


# ---------------- مرور دسته‌بندی‌ها ----------------
@router.message(F.text == "🛍 دسته‌بندی‌ها")
async def show_categories(message: Message):
    cats = await db.get_categories(parent_id=None)
    if not cats:
        await message.answer("هنوز هیچ دسته‌بندی‌ای ثبت نشده است.")
        return
    await message.answer("یک دسته‌بندی را انتخاب کنید:", reply_markup=categories_kb(cats))


async def render_category(category_id: int, page: int = 0):
    cat = await db.get_category(category_id)
    if not cat:
        return None, None
    sub_cats = await db.get_categories(parent_id=category_id)
    if sub_cats:
        text = f"📁 {cat[1]}\nیکی از زیردسته‌ها را انتخاب کنید:"
        kb = categories_kb(sub_cats, parent_id=cat[2], show_back=True)
        return text, kb

    products = await db.get_products_by_category(category_id)
    total_pages = max(1, (len(products) + PRODUCTS_PER_PAGE - 1) // PRODUCTS_PER_PAGE)
    page = min(page, total_pages - 1)
    chunk = products[page * PRODUCTS_PER_PAGE: (page + 1) * PRODUCTS_PER_PAGE]
    chunk_view = [(p[0], p[1], p[3], p[4]) for p in chunk]
    text = f"📁 {cat[1]}" if products else f"📁 {cat[1]}\nهنوز محصولی در این دسته ثبت نشده."
    kb = category_view_kb(category_id, chunk_view, cat[2], page, total_pages)
    return text, kb


@router.callback_query(F.data.startswith("cat:"))
async def open_category(call: CallbackQuery):
    category_id = int(call.data.split(":")[1])
    text, kb = await render_category(category_id)
    await call.message.edit_text(text, reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith("catpage:"))
async def paginate_category(call: CallbackQuery):
    _, category_id, page = call.data.split(":")
    text, kb = await render_category(int(category_id), int(page))
    await call.message.edit_text(text, reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith("catback:"))
async def back_category(call: CallbackQuery):
    target = call.data.split(":")[1]
    if target == "root":
        cats = await db.get_categories(parent_id=None)
        await call.message.edit_text("یک دسته‌بندی را انتخاب کنید:", reply_markup=categories_kb(cats))
    else:
        text, kb = await render_category(int(target))
        await call.message.edit_text(text, reply_markup=kb)
    await call.answer()


@router.callback_query(F.data.startswith("catback_view:"))
async def back_to_category_view(call: CallbackQuery):
    category_id = int(call.data.split(":")[1])
    text, kb = await render_category(category_id)
    try:
        await call.message.delete()
    except Exception:
        pass
    await call.message.answer(text, reply_markup=kb)
    await call.answer()


# ---------------- نمایش محصول ----------------
@router.callback_query(F.data.startswith("prod:"))
async def view_product(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    p = await db.get_product(product_id)
    if not p or not p[7]:
        await call.answer("این محصول موجود نیست.", show_alert=True)
        return
    _, category_id, name, description, price, stock, photo_file_id, is_active = p
    caption = f"🏷 <b>{name}</b>\n\n{description or ''}\n\n💰 قیمت: {price:,} تومان\n📦 موجودی: {stock if stock > 0 else 'ناموجود'}"
    kb = product_view_kb(product_id, category_id, in_stock=stock > 0)
    if photo_file_id:
        await call.message.answer_photo(photo_file_id, caption=caption, reply_markup=kb, parse_mode="HTML")
    else:
        await call.message.answer(caption, reply_markup=kb, parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data.startswith("addcart:"))
async def add_cart(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    p = await db.get_product(product_id)
    if not p or p[5] <= 0 or not p[7]:
        await call.answer("این محصول موجود نیست.", show_alert=True)
        return
    await db.add_to_cart(call.from_user.id, product_id, 1)
    await call.answer("✅ به سبد خرید اضافه شد.")


# ---------------- جستجو ----------------
@router.message(F.text == "🔎 جستجوی محصول")
async def search_start(message: Message, state: FSMContext):
    await state.set_state(SearchProduct.keyword)
    await message.answer("نام محصول مورد نظر را بفرستید:", reply_markup=cancel_kb())


@router.message(SearchProduct.keyword)
async def search_result(message: Message, state: FSMContext):
    await state.clear()
    results = await db.search_products(message.text.strip())
    if not results:
        await message.answer("چیزی پیدا نشد.", reply_markup=main_menu_kb())
        return
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    b = InlineKeyboardBuilder()
    for p_id, name, price, stock in results:
        label = f"{name} - {price:,} تومان" + (" (ناموجود)" if stock <= 0 else "")
        b.row(InlineKeyboardButton(text=label, callback_data=f"prod:{p_id}"))
    await message.answer("نتایج جستجو:", reply_markup=b.as_markup())


# ---------------- سبد خرید ----------------
@router.message(F.text == "🛒 سبد خرید")
async def show_cart(message: Message):
    items = await db.get_cart(message.from_user.id)
    if not items:
        await message.answer("سبد خرید شما خالی است.")
        return
    total = sum(price * qty for _, _, price, qty, _ in items)
    text = "🛒 سبد خرید شما:\n\n" + "\n".join(
        f"• {name} × {qty} = {price*qty:,} تومان" for _, name, price, qty, _ in items
    )
    text += f"\n\n💰 جمع کل: {total:,} تومان"
    await message.answer(text, reply_markup=cart_kb(items))


@router.callback_query(F.data == "noop")
async def noop(call: CallbackQuery):
    await call.answer()


async def refresh_cart_message(call: CallbackQuery):
    items = await db.get_cart(call.from_user.id)
    if not items:
        try:
            await call.message.edit_text("سبد خرید شما خالی است.")
        except Exception:
            pass
        return
    total = sum(price * qty for _, _, price, qty, _ in items)
    text = "🛒 سبد خرید شما:\n\n" + "\n".join(
        f"• {name} × {qty} = {price*qty:,} تومان" for _, name, price, qty, _ in items
    )
    text += f"\n\n💰 جمع کل: {total:,} تومان"
    try:
        await call.message.edit_text(text, reply_markup=cart_kb(items))
    except Exception:
        pass


@router.callback_query(F.data.startswith("cartinc:"))
async def cart_inc(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    p = await db.get_product(product_id)
    items = await db.get_cart(call.from_user.id)
    current = next((q for pid, _, _, q, _ in items if pid == product_id), 0)
    if p and current + 1 > p[5]:
        await call.answer("موجودی کافی نیست.", show_alert=True)
        return
    await db.add_to_cart(call.from_user.id, product_id, 1)
    await refresh_cart_message(call)
    await call.answer()


@router.callback_query(F.data.startswith("cartdec:"))
async def cart_dec(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    items = await db.get_cart(call.from_user.id)
    current = next((q for pid, _, _, q, _ in items if pid == product_id), 0)
    await db.set_cart_qty(call.from_user.id, product_id, current - 1)
    await refresh_cart_message(call)
    await call.answer()


@router.callback_query(F.data.startswith("cartdel:"))
async def cart_del(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    await db.remove_from_cart(call.from_user.id, product_id)
    await refresh_cart_message(call)
    await call.answer("حذف شد.")


@router.callback_query(F.data == "cartclear")
async def cart_clear(call: CallbackQuery):
    await db.clear_cart(call.from_user.id)
    await refresh_cart_message(call)
    await call.answer("سبد خرید خالی شد.")


# ---------------- تکمیل سفارش (Checkout) ----------------
@router.callback_query(F.data == "checkout")
async def checkout_start(call: CallbackQuery, state: FSMContext):
    items = await db.get_cart(call.from_user.id)
    if not items:
        await call.answer("سبد خرید خالی است.", show_alert=True)
        return
    for p_id, name, price, qty, stock in items:
        if qty > stock:
            await call.answer(f"موجودی «{name}» کافی نیست.", show_alert=True)
            return
    await state.set_state(Checkout.full_name)
    await call.message.answer("لطفاً نام و نام خانوادگی خود را وارد کنید:", reply_markup=cancel_kb())
    await call.answer()


@router.callback_query(F.data == "cancel_flow")
async def cancel_flow(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("عملیات لغو شد.", reply_markup=main_menu_kb())
    await call.answer()


@router.message(Checkout.full_name)
async def checkout_full_name(message: Message, state: FSMContext):
    await state.update_data(full_name=message.text.strip())
    await state.set_state(Checkout.phone)
    await message.answer("شماره تماس خود را وارد کنید:", reply_markup=cancel_kb())


@router.message(Checkout.phone)
async def checkout_phone(message: Message, state: FSMContext):
    await state.update_data(phone=message.text.strip())
    await state.set_state(Checkout.address)
    await message.answer("آدرس کامل ارسال را وارد کنید:", reply_markup=cancel_kb())


@router.message(Checkout.address)
async def checkout_address(message: Message, state: FSMContext):
    await state.update_data(address=message.text.strip())
    data = await state.get_data()
    items = await db.get_cart(message.from_user.id)
    total = sum(price * qty for _, _, price, qty, _ in items)
    lines = [f"• {name} × {qty} = {price*qty:,} تومان" for _, name, price, qty, _ in items]
    text = (
        "📋 خلاصه سفارش:\n\n" + "\n".join(lines) +
        f"\n\n💰 جمع کل: {total:,} تومان\n\n👤 نام: {data['full_name']}\n📞 تلفن: {data['phone']}\n🏠 آدرس: {message.text.strip()}\n\nآیا اطلاعات صحیح است؟"
    )
    await message.answer(text, reply_markup=confirm_checkout_kb())


@router.callback_query(F.data == "checkout_cancel")
async def checkout_cancel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("سفارش لغو شد.", reply_markup=main_menu_kb())
    await call.answer()


@router.callback_query(F.data == "checkout_confirm")
async def checkout_confirm(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    items = await db.get_cart(call.from_user.id)
    if not items:
        await call.answer("سبد خرید خالی است.", show_alert=True)
        await state.clear()
        return
    total = sum(price * qty for _, _, price, qty, _ in items)
    order_items = [{"id": pid, "name": name, "price": price, "quantity": qty} for pid, name, price, qty, _ in items]
    order_id = await db.create_order(call.from_user.id, data["full_name"], data["phone"], data["address"], total, order_items)
    await state.update_data(order_id=order_id)
    await state.set_state(Checkout.waiting_receipt)

    card_number = await db.get_setting("card_number")
    card_holder = await db.get_setting("card_holder")
    await call.message.answer(
        f"✅ سفارش شما با شماره #{order_id} ثبت شد.\n\n"
        f"💳 لطفاً مبلغ {total:,} تومان را به شماره کارت زیر واریز کنید:\n\n"
        f"<code>{card_number}</code>\nبه نام: {card_holder}\n\n"
        f"سپس عکس رسید پرداخت را همینجا ارسال کنید.",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(Checkout.waiting_receipt, F.photo)
async def receive_receipt(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    order_id = data["order_id"]
    file_id = message.photo[-1].file_id
    await db.attach_receipt(order_id, file_id)
    await db.clear_cart(message.from_user.id)
    await state.clear()
    await message.answer(
        "✅ رسید دریافت شد. سفارش شما در انتظار بررسی و تایید ادمین است.\n"
        "به محض تایید، نتیجه به شما اطلاع داده می‌شود.",
        reply_markup=main_menu_kb(),
    )

    order = await db.get_order(order_id)
    order_items = await db.get_order_items(order_id)
    items_text = "\n".join(f"• {n} × {q} = {p*q:,} تومان" for _, n, p, q in order_items)
    admin_text = (
        f"🆕 سفارش جدید #{order_id}\n\n"
        f"👤 {order[2]}\n📞 {order[3]}\n🏠 {order[4]}\n\n{items_text}\n\n"
        f"💰 جمع کل: {order[5]:,} تومان"
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_photo(admin_id, file_id, caption=admin_text, reply_markup=admin_order_action_kb(order_id))
        except Exception:
            pass


@router.message(Checkout.waiting_receipt)
async def waiting_receipt_wrong_type(message: Message):
    await message.answer("لطفاً عکس رسید پرداخت را ارسال کنید.")


# ---------------- سفارش‌های من ----------------
@router.message(F.text == "📦 سفارش‌های من")
async def my_orders(message: Message):
    orders = await db.get_user_orders(message.from_user.id)
    if not orders:
        await message.answer("شما هنوز سفارشی ثبت نکرده‌اید.")
        return
    status_fa = {
        "pending_receipt": "⏳ در انتظار ارسال رسید",
        "pending_review": "🔍 در انتظار بررسی ادمین",
        "confirmed": "✅ تایید شده",
        "rejected": "❌ رد شده",
    }
    lines = []
    for order_id, total, status, created_at in orders:
        lines.append(f"#{order_id} | {total:,} تومان | {status_fa.get(status, status)} | {created_at}")
    await message.answer("📦 سفارش‌های شما:\n\n" + "\n".join(lines))
